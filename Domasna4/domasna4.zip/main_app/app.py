
from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home_page.html')  # Home page

@app.route('/home_logged')
def home_logged():
    return render_template('home_page_logged.html')  # Home page for logged users

@app.route('/login')
def login():
    return render_template('login.html')  # Login page

@app.route('/profile')
def profile():
    return render_template('profile.html')  # Profile page

@app.route('/signup')
def signup():
    return render_template('signup.html')  # Signup page

@app.route('/stockdata')
def stockdata():
    return render_template('stockdata.html')  # Stock data page

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
