from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import csv
import re
from datetime import datetime  # To capture the current date
import os
from myScript import load_from_csv, save_to_csv, scrape_firm, valid_firms  # Import your existing scraping functions

app = Flask(__name__, static_folder='images', static_url_path='/static')
app.secret_key = 'your_secret_key'

# File paths
USER_DATA_FILE = 'user_data.csv'

# Ensure the CSV file exists for users
if not os.path.exists(USER_DATA_FILE):
    with open(USER_DATA_FILE, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['First Name', 'Last Name', 'Date of Birth', 'Email', 'Username', 'Password', 'Date Joined'])

# Signup route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        # Get form data
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        dob = request.form['dob']
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']
        date_joined = datetime.now().strftime('%Y-%m-%d')  # Current date when the user signs up

        # Append user data to the CSV file
        with open(USER_DATA_FILE, 'a', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([first_name, last_name, dob, email, username, password, date_joined])

        return "Signup successful! You can now <a href='/login'>log in</a>."
    return render_template('signup.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        with open(USER_DATA_FILE, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                if row[4] == username and row[5] == password:
                    session['username'] = username
                    flash('Login successful!', 'success')
                    return redirect(url_for('profile'))
        flash('Invalid username or password.', 'error')

    return render_template('login.html')

# Profile route
@app.route('/profile')
def profile():
    if 'username' not in session:
        flash('You need to log in first.', 'error')
        return redirect(url_for('login'))

    # Find the user details
    user = None
    with open(USER_DATA_FILE, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[4] == session['username']:
                user = {
                    'name': row[0],
                    'lastname': row[1],
                    'dob': row[2],
                    'email': row[3],
                    'username': row[4],
                    'date_joined': row[6]  # Date joined is now part of the CSV
                }
                break
    return render_template('profile.html', user=user)
@app.route('/')
def home():
    return render_template('home_page.html')  # Ensure this template exists in your templates folder
def read_csv():
    data = []
    with open('scraped_data.csv', newline='', encoding='utf-8') as csvfile:
        csvreader = csv.reader(csvfile)
        headers = next(csvreader)  # Skip header row
        for row in csvreader:
            data.append(row)
    return headers, data

@app.route('/stockdata')
def stockdata():
    return render_template('stockdata.html')  # Ensure this template exists in your templates folder
@app.route('/homelogged')
def homelogged():
    return render_template('home_page_logged.html')  # Ensure this template exists in your templates folder
# Function to clean and split the 4th column while respecting commas inside quotes
def clean_column(column_data):
    # Replace commas inside quotes with a placeholder to prevent splitting
    column_data = re.sub(r"('[^']*')", lambda m: m.group(0).replace(",", "|comma|"), column_data)

    # Split by commas (this will not split inside quotes)
    split_data = column_data.split(',')

    # Restore commas inside quotes
    split_data = [item.replace("|comma|", ",") for item in split_data]

    # Ensure Min and Max are not null or empty
    if len(split_data) > 3:  # Ensure there are enough elements in the split data (Date, Last Trade Price, Max, Min, etc.)
        last_trade_price = split_data[1]  # Last Trade Price is in index 1
        split_data[2]=last_trade_price
        split_data[3] = last_trade_price
        # Check for empty or null values and replace with the Last Trade Price (index 1)


    return split_data

@app.route('/logout')
def logout():
    return render_template('home_page.html')



import logging

logging.basicConfig(level=logging.DEBUG)  # Set the logging level to debug


@app.route('/filter', methods=['GET'])
def filter_data():
    try:
        selected_issuer = request.args.get('issuer')
        logging.debug(f"Selected issuer: {selected_issuer}")  # Log the selected issuer

        headers, data = read_csv()
        logging.debug(f"Data read from CSV: {data[:5]}")  # Log the first 5 rows of data

        filtered_data = []
        for row in data:
            if row[0] == selected_issuer:  # Check if issuer matches the first column
                clean_row = clean_column(row[3])
                filtered_data.append(clean_row)

        if len(filtered_data) == 0:
            logging.debug(f"No data found for {selected_issuer}.")
            return jsonify({"error": f"No data found for {selected_issuer}"}), 404



        return jsonify({ 'data': filtered_data,})


    except Exception as e:
        logging.error(f"Error occurred: {e}", exc_info=True)  # Log the full exception
        return jsonify({"error": "An error occurred, please check server logs for details"}), 500

@app.route('/start-scraping', methods=['POST'])
def start_scraping():
    try:
        # Initialize scraping by loading previous records
        load_from_csv()

        # Start scraping data for each firm
        for firm in valid_firms:
            scrape_firm(firm)

        # After scraping, save the results
        save_to_csv()

        return "Scraping completed successfully!"
    except Exception as e:
        return f"Error during scraping: {e}"


if __name__ == '__main__':
    app.run(debug=True)
